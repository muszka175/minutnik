package com.example.kindz.minutnik;


import android.media.MediaPlayer;
import android.os.Build;

import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.Timer;
import java.util.TimerTask;



public class Minutnik extends AppCompatActivity implements View.OnClickListener {

    static EditText sj;
    static EditText sdz;
    static EditText mj;
    static EditText mdz;
    EditText colon;
    Button psj;
    Button msj;
    Button psdz;
    Button msdz;
    Button pmj;
    Button mmj;
    Button pmdz;
    Button mmdz;
    Button start;
    Button pauza;
    Button stop;

    Timer t;
    TimerTask task;
    MediaPlayer mediaPlayer;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_minutnik);



        psj = (Button) findViewById(R.id.psj);
        msj = (Button) findViewById(R.id.msj);

        pmj = (Button) findViewById(R.id.pmj);
        msj = (Button) findViewById(R.id.msj);

        psdz = (Button) findViewById(R.id.psdz);
        msdz = (Button) findViewById(R.id.msdz);

        pmj = (Button) findViewById(R.id.pmj);
        mmj = (Button) findViewById(R.id.mmj);

        pmdz = (Button) findViewById(R.id.pmdz);
        mmdz = (Button) findViewById(R.id.mmdz);

        start = (Button) findViewById(R.id.start);
        pauza = (Button) findViewById(R.id.pauza);
        stop = (Button) findViewById(R.id.stop);

        sj = (EditText) findViewById(R.id.sj);
        sdz = (EditText) findViewById(R.id.sdz);
        mj = (EditText) findViewById(R.id.mj);
        mdz = (EditText) findViewById(R.id.mdz);


        psj.setOnClickListener(this);
        msj.setOnClickListener(this);

        psdz.setOnClickListener(this);
        msdz.setOnClickListener(this);

        pmj.setOnClickListener(this);
        mmj.setOnClickListener(this);

        pmdz.setOnClickListener(this);
        mmdz.setOnClickListener(this);

        start.setOnClickListener(this);
        pauza.setOnClickListener(this);
        stop.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {


        try {

            switch (view.getId()) {

                case R.id.psj:
                    int a = Integer.parseInt(sj.getText().toString());
                    int b = a + 1;
                    if (b > 9) {
                        b = 9;
                    }
                    sj.setText(new Integer(b).toString());
                    break;

                case R.id.msj:
                    int c = Integer.parseInt(sj.getText().toString());
                    int d = c - 1;
                    if (d < 0) {
                        d = 0;
                    }
                    sj.setText(new Integer(d).toString());
                    break;

                case R.id.psdz:
                    int a1 = Integer.parseInt(sdz.getText().toString());
                    int b1 = a1 + 1;
                    if (b1 > 5) {
                        b1 = 5;
                    }
                    sdz.setText(new Integer(b1).toString());
                    break;

                case R.id.msdz:
                    int c1 = Integer.parseInt(sdz.getText().toString());
                    int d1 = c1 - 1;
                    if (d1 < 0) {
                        d1 = 0;
                    }
                    sdz.setText(new Integer(d1).toString());
                    break;

                case R.id.pmj:
                    int a2 = Integer.parseInt(mj.getText().toString());
                    int b2 = a2 + 1;
                    if (b2 > 9) {
                        b2 = 9;
                    }
                    mj.setText(new Integer(b2).toString());
                    break;

                case R.id.mmj:
                    int c2 = Integer.parseInt(mj.getText().toString());
                    int d2 = c2 - 1;
                    if (d2 < 0) {
                        d2 = 0;
                    }
                    mj.setText(new Integer(d2).toString());
                    break;

                case R.id.pmdz:
                    int a3 = Integer.parseInt(mdz.getText().toString());
                    int b3 = a3 + 1;
                    if (b3 > 5) {
                        b3 = 5;
                    }
                    mdz.setText(new Integer(b3).toString());
                    break;

                case R.id.mmdz:
                    int c3 = Integer.parseInt(mdz.getText().toString());
                    int d3 = c3 - 1;
                    if (d3 < 0) {
                        d3 = 0;
                    }
                    mdz.setText(new Integer(d3).toString());
                    break;

                case R.id.start:

                    startTimer();

                    break;
                case R.id.pauza:

                    t.cancel();

                    break;
                case R.id.stop:

                    t.cancel();
                    stopTimer();


                    break;
            }
        } catch (NumberFormatException e) {
        };
    }

    public void startTimer() {
        t = new Timer();
        task = new TimerTask() {

            int sekjedn = Integer.parseInt(sj.getText().toString());
            int sekdzies = Integer.parseInt(sdz.getText().toString());

            int minjedn = Integer.parseInt(mj.getText().toString());
            int mindzies = Integer.parseInt(mdz.getText().toString());

            int czasSek = sekjedn + (sekdzies * 10) + (minjedn * 60) + (mindzies * 600);

            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @RequiresApi(api = Build.VERSION_CODES.N)
                    @Override
                    public void run() {


                        Log.d("ADebugTag", "Value: " + Float.toString(czasSek));


                        if (czasSek > 0) {

                            czasSek -= 1;
                            mindzies =  (czasSek/60)/10;
                            minjedn = (czasSek/60)%10;
                            sekdzies = (czasSek%60)/10;
                            sekjedn = (czasSek%60)%10;

                            Log.d("ADebugTag", "Value: " + Float.toString(czasSek));



                            sj.setText(sekjedn+"");
                            sdz.setText(sekdzies+"");
                            mj.setText(minjedn+"");
                            mdz.setText(mindzies+"");
                        }
                        else {


                            t.cancel();
                            mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.beep);
                            mediaPlayer.start();
                            return;
                        }
                    }
                });
            }
        };
        t.scheduleAtFixedRate(task, 0, 1000);
    }

    public void stopTimer()
    {
        sj.setText("0");
        sdz.setText("0");
        mj.setText("0");
        mdz.setText("0");
    }

}


